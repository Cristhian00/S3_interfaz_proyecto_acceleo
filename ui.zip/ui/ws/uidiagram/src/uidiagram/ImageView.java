/**
 */
package uidiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Image View</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see uidiagram.UidiagramPackage#getImageView()
 * @model annotation="gmf.node label='title'"
 * @generated
 */
public interface ImageView extends GraphicalIndividual {
} // ImageView
