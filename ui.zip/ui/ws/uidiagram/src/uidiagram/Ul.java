/**
 */
package uidiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ul</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see uidiagram.UidiagramPackage#getUl()
 * @model annotation="gmf.node label='title'"
 * @generated
 */
public interface Ul extends GraphicalIndividual {
} // Ul
