/**
 */
package uidiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Container</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see uidiagram.UidiagramPackage#getContainer()
 * @model annotation="gmf.node label='title'"
 * @generated
 */
public interface Container extends GraphicalContainer {
} // Container
