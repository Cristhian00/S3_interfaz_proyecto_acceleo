/**
 */
package uidiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Graphical Individual</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see uidiagram.UidiagramPackage#getGraphicalIndividual()
 * @model abstract="true"
 * @generated
 */
public interface GraphicalIndividual extends ModelElement {
} // GraphicalIndividual
