/**
 */
package uidiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IFrame</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see uidiagram.UidiagramPackage#getIFrame()
 * @model annotation="gmf.node label='title'"
 * @generated
 */
public interface IFrame extends GraphicalContainer {
} // IFrame
