/**
 */
package uidiagram.impl;

import org.eclipse.emf.ecore.EClass;

import uidiagram.UidiagramPackage;
import uidiagram.Ul;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Ul</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class UlImpl extends GraphicalIndividualImpl implements Ul {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UlImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UidiagramPackage.Literals.UL;
	}

} //UlImpl
