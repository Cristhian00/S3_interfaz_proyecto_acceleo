/**
 */
package uidiagram.impl;

import org.eclipse.emf.ecore.EClass;

import uidiagram.Select;
import uidiagram.UidiagramPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Select</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SelectImpl extends GraphicalIndividualImpl implements Select {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SelectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UidiagramPackage.Literals.SELECT;
	}

} //SelectImpl
