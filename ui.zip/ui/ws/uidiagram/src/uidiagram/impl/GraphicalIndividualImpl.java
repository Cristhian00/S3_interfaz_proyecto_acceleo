/**
 */
package uidiagram.impl;

import org.eclipse.emf.ecore.EClass;

import uidiagram.GraphicalIndividual;
import uidiagram.UidiagramPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Graphical Individual</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class GraphicalIndividualImpl extends ModelElementImpl implements GraphicalIndividual {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GraphicalIndividualImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UidiagramPackage.Literals.GRAPHICAL_INDIVIDUAL;
	}

} //GraphicalIndividualImpl
