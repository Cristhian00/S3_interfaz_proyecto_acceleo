/**
 */
package uidiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Blockquote</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see uidiagram.UidiagramPackage#getBlockquote()
 * @model annotation="gmf.node label='title'"
 * @generated
 */
public interface Blockquote extends GraphicalIndividual {
} // Blockquote
