/**
 */
package uidiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Select</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see uidiagram.UidiagramPackage#getSelect()
 * @model annotation="gmf.node label='title'"
 * @generated
 */
public interface Select extends GraphicalIndividual {
} // Select
