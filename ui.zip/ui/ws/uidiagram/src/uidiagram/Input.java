/**
 */
package uidiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see uidiagram.UidiagramPackage#getInput()
 * @model annotation="gmf.node label='title' label.icon='false'"
 * @generated
 */
public interface Input extends GraphicalIndividual {
} // Input
