/**
 */
package uidiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Button</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see uidiagram.UidiagramPackage#getButton()
 * @model annotation="gmf.node label='title' label.icon='false'"
 * @generated
 */
public interface Button extends GraphicalIndividual {
} // Button
