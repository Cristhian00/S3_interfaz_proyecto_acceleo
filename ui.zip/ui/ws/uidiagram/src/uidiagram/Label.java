/**
 */
package uidiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Label</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see uidiagram.UidiagramPackage#getLabel()
 * @model annotation="gmf.node figure='rectangle' label='title' label.icon='false'"
 * @generated
 */
public interface Label extends GraphicalIndividual {
} // Label
