/*
 * 
 */
package uidiagram.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	* @generated
	*/
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Messages() {
	}

	/**
	* @generated
	*/
	public static String UidiagramCreationWizardTitle;

	/**
	* @generated
	*/
	public static String UidiagramCreationWizard_DiagramModelFilePageTitle;

	/**
	* @generated
	*/
	public static String UidiagramCreationWizard_DiagramModelFilePageDescription;

	/**
	* @generated
	*/
	public static String UidiagramCreationWizard_DomainModelFilePageTitle;

	/**
	* @generated
	*/
	public static String UidiagramCreationWizard_DomainModelFilePageDescription;

	/**
	* @generated
	*/
	public static String UidiagramCreationWizardOpenEditorError;

	/**
	* @generated
	*/
	public static String UidiagramCreationWizardCreationError;

	/**
	* @generated
	*/
	public static String UidiagramCreationWizardPageExtensionError;

	/**
	* @generated
	*/
	public static String UidiagramDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String UidiagramDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String UidiagramDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	* @generated
	*/
	public static String UidiagramDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	* @generated
	*/
	public static String UidiagramDocumentProvider_isModifiable;

	/**
	* @generated
	*/
	public static String UidiagramDocumentProvider_handleElementContentChanged;

	/**
	* @generated
	*/
	public static String UidiagramDocumentProvider_IncorrectInputError;

	/**
	* @generated
	*/
	public static String UidiagramDocumentProvider_NoDiagramInResourceError;

	/**
	* @generated
	*/
	public static String UidiagramDocumentProvider_DiagramLoadingError;

	/**
	* @generated
	*/
	public static String UidiagramDocumentProvider_UnsynchronizedFileSaveError;

	/**
	* @generated
	*/
	public static String UidiagramDocumentProvider_SaveDiagramTask;

	/**
	* @generated
	*/
	public static String UidiagramDocumentProvider_SaveNextResourceTask;

	/**
	* @generated
	*/
	public static String UidiagramDocumentProvider_SaveAsOperation;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String InitDiagramFile_WizardTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	* @generated
	*/
	public static String UidiagramNewDiagramFileWizard_CreationPageName;

	/**
	* @generated
	*/
	public static String UidiagramNewDiagramFileWizard_CreationPageTitle;

	/**
	* @generated
	*/
	public static String UidiagramNewDiagramFileWizard_CreationPageDescription;

	/**
	* @generated
	*/
	public static String UidiagramNewDiagramFileWizard_RootSelectionPageName;

	/**
	* @generated
	*/
	public static String UidiagramNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	* @generated
	*/
	public static String UidiagramNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	* @generated
	*/
	public static String UidiagramNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	* @generated
	*/
	public static String UidiagramNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	* @generated
	*/
	public static String UidiagramNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	* @generated
	*/
	public static String UidiagramNewDiagramFileWizard_InitDiagramCommand;

	/**
	* @generated
	*/
	public static String UidiagramNewDiagramFileWizard_IncorrectRootError;

	/**
	* @generated
	*/
	public static String UidiagramDiagramEditor_SavingDeletedFile;

	/**
	* @generated
	*/
	public static String UidiagramDiagramEditor_SaveAsErrorTitle;

	/**
	* @generated
	*/
	public static String UidiagramDiagramEditor_SaveAsErrorMessage;

	/**
	* @generated
	*/
	public static String UidiagramDiagramEditor_SaveErrorTitle;

	/**
	* @generated
	*/
	public static String UidiagramDiagramEditor_SaveErrorMessage;

	/**
	* @generated
	*/
	public static String UidiagramElementChooserDialog_SelectModelElementTitle;

	/**
	* @generated
	*/
	public static String ModelElementSelectionPageMessage;

	/**
	* @generated
	*/
	public static String ValidateActionMessage;

	/**
	* @generated
	*/
	public static String Objects1Group_title;

	/**
	* @generated
	*/
	public static String Blockquote1CreationTool_title;

	/**
	* @generated
	*/
	public static String Blockquote1CreationTool_desc;

	/**
	* @generated
	*/
	public static String Button2CreationTool_title;

	/**
	* @generated
	*/
	public static String Button2CreationTool_desc;

	/**
	* @generated
	*/
	public static String Column3CreationTool_title;

	/**
	* @generated
	*/
	public static String Column3CreationTool_desc;

	/**
	* @generated
	*/
	public static String Container4CreationTool_title;

	/**
	* @generated
	*/
	public static String Container4CreationTool_desc;

	/**
	* @generated
	*/
	public static String IFrame5CreationTool_title;

	/**
	* @generated
	*/
	public static String IFrame5CreationTool_desc;

	/**
	* @generated
	*/
	public static String ImageView6CreationTool_title;

	/**
	* @generated
	*/
	public static String ImageView6CreationTool_desc;

	/**
	* @generated
	*/
	public static String Input7CreationTool_title;

	/**
	* @generated
	*/
	public static String Input7CreationTool_desc;

	/**
	* @generated
	*/
	public static String Label8CreationTool_title;

	/**
	* @generated
	*/
	public static String Label8CreationTool_desc;

	/**
	* @generated
	*/
	public static String Select9CreationTool_title;

	/**
	* @generated
	*/
	public static String Select9CreationTool_desc;

	/**
	* @generated
	*/
	public static String Table10CreationTool_title;

	/**
	* @generated
	*/
	public static String Table10CreationTool_desc;

	/**
	* @generated
	*/
	public static String Ul11CreationTool_title;

	/**
	* @generated
	*/
	public static String Ul11CreationTool_desc;

	/**
	* @generated
	*/
	public static String UserInterface12CreationTool_title;

	/**
	* @generated
	*/
	public static String UserInterface12CreationTool_desc;

	/**
	* @generated
	*/
	public static String UserInterfaceUserInterfaceLstModelElementsCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String ContainerContainerLstChildModelElementsCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String ContainerContainerLstChildModelElementsCompartment2EditPart_title;

	/**
	* @generated
	*/
	public static String IFrameIFrameLstChildModelElementsCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String TableTableLstChildModelElementsCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String ColumnColumnLstChildModelElementsCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String IFrameIFrameLstChildModelElementsCompartment2EditPart_title;

	/**
	* @generated
	*/
	public static String TableTableLstChildModelElementsCompartment2EditPart_title;

	/**
	* @generated
	*/
	public static String ColumnColumnLstChildModelElementsCompartment2EditPart_title;

	/**
	* @generated
	*/
	public static String CommandName_OpenDiagram;

	/**
	* @generated
	*/
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	* @generated
	*/
	public static String MessageFormatParser_InvalidInputError;

	/**
	* @generated
	*/
	public static String UidiagramModelingAssistantProviderTitle;

	/**
	* @generated
	*/
	public static String UidiagramModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
