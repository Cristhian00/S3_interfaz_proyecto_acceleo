/*
 * 
 */
package uidiagram.diagram.edit.helpers;

/**
 * @generated
 */
public class SelectEditHelper extends UidiagramBaseEditHelper {
}
