/*
 * 
 */
package uidiagram.diagram.edit.helpers;

/**
 * @generated
 */
public class InputEditHelper extends UidiagramBaseEditHelper {
}
