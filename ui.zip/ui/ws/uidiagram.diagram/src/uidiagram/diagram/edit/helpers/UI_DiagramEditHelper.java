/*
 * 
 */
package uidiagram.diagram.edit.helpers;

/**
 * @generated
 */
public class UI_DiagramEditHelper extends UidiagramBaseEditHelper {
}
