/*
 * 
 */
package uidiagram.diagram.edit.helpers;

/**
 * @generated
 */
public class ContainerEditHelper extends UidiagramBaseEditHelper {
}
