/*
 * 
 */
package uidiagram.diagram.edit.helpers;

/**
 * @generated
 */
public class UserInterfaceEditHelper extends UidiagramBaseEditHelper {
}
