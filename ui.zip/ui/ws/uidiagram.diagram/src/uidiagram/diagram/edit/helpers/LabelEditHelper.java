/*
 * 
 */
package uidiagram.diagram.edit.helpers;

/**
 * @generated
 */
public class LabelEditHelper extends UidiagramBaseEditHelper {
}
