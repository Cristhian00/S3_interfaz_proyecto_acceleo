/*
 * 
 */
package uidiagram.diagram.edit.helpers;

/**
 * @generated
 */
public class UlEditHelper extends UidiagramBaseEditHelper {
}
