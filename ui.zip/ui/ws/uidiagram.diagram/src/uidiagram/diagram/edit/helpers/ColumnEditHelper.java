/*
 * 
 */
package uidiagram.diagram.edit.helpers;

/**
 * @generated
 */
public class ColumnEditHelper extends UidiagramBaseEditHelper {
}
