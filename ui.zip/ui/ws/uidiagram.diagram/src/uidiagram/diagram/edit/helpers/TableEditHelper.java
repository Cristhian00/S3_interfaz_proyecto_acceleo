/*
 * 
 */
package uidiagram.diagram.edit.helpers;

/**
 * @generated
 */
public class TableEditHelper extends UidiagramBaseEditHelper {
}
