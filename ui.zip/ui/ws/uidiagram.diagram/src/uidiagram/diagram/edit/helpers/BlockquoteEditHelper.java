/*
 * 
 */
package uidiagram.diagram.edit.helpers;

/**
 * @generated
 */
public class BlockquoteEditHelper extends UidiagramBaseEditHelper {
}
