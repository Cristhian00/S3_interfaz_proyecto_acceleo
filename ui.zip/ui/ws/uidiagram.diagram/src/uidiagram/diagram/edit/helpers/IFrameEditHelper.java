/*
 * 
 */
package uidiagram.diagram.edit.helpers;

/**
 * @generated
 */
public class IFrameEditHelper extends UidiagramBaseEditHelper {
}
